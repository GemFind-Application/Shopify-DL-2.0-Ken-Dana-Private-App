  <footer class="footer">
  	<div class="container">
  		<div class="text-center">
  			<p>Copyright © 2020 Lucki Media All Rights Reserved | <a href="#">Lucki Media</a></p>
  		</div>
  	</div>
  </footer>